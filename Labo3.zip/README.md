TP LaboratorioIV 2016
========================================


**Trabajo práctico  de los alumnos de laboratorio IV.**

<h4>Las siguientes empresas nos solicitan la creación de aplicaciones para administrar sus negocios:</h4>

  - Pizzerías Argenta SRL
  - Inmobiliarias El Campito  S.A.


<h4>El trabajo práctico deberá contener los siguientes ítem además de los requerimientos funcionales del sistema</h4>
 - ABM.
 - login (JWT).
 - Botones de test ( Administrador, encargado,empleado y cliente).
 - WEbServer(API rest).
 - Geo localización.
 - Generar documentos Excel.
 - Generar Documentos pdf .
 - Generar graficos estadísticos.
 - Responsive / estilos aplicados de forma estética.
 - manejo de imágenes.
 - creación de directivas.
 - servicios y Factory
 - filtros



-------------------------------------------------------------------------------------
<h5>Objetivo:Lograr una aplicacion funcional sin errores.</h5>
-------------------------------------------------------------------------------------










